package com.vsmanutencoes.sistemaweb.models;

public enum StatusSolicitacao {
    PENDENTE,
    EM_ANDAMENTO,
    FINALIZADA,
    CANCELADA;
}
